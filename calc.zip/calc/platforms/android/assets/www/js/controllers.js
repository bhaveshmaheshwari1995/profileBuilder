angular.module('starter.controllers', [])

.controller('FormCtrl', function($scope, $stateParams) {

$scope.formdata={};
 $scope.onsubmit=function(){

  alert("Home Value"+$scope.formdata.homeValue +" Loan Amount "+ $scope.formdata.loanAmount+" interest Rate "
    +$scope.formdata.interestRate +" Loan Term"+ $scope.formdata.loanTerm+" Property Tax "+
     $scope.formdata.propertyTax+" PMI "+$scope.formdata.pmi);
 }
});

